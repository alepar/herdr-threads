import collections, datetime, hashlib, json, os, pathlib, signal, shutil, subprocess, time
root=pathlib.Path.cwd(); out=root/'target/queue-qualification'; source='7090d18af6996f7fdaed96717fef1f16c77883ba'; run_id='93b01690-2f88-4c66-839a-1671542e08c0'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','main'],text=True).strip()=='4dabf06ef90c8c9e8c459b524b509af3a2e98b31'
assert subprocess.check_output(['git','merge-tree','--write-tree','main','HEAD'],text=True).strip()=='2de5287d691c34d7170969d006bc28457ae36f00'
assert not (out/'hint-fixed-tree-time.json').exists() and not (out/'hint-fixed-tree-suite.log').exists(), 'final suite already started; never repeat blindly'
config=hashlib.sha256((root/'.config/nextest.toml').read_bytes()).hexdigest()
argv=['/var/home/alepar/.cache/herdr-threads-heavy/heavy','/var/home/alepar/.cache/herdr-threads-heavy/tb','nice','-n','19','cargo','nextest','run','--locked','--all-targets','--all-features','--profile','ci','-j','4']
env=os.environ.copy(); env.update(HT_LEAK_RUN_ID=run_id,CARGO_BUILD_JOBS='4',NEXTEST_TEST_THREADS='4',RUST_TEST_THREADS='4',CARGO_TARGET_DIR=str(root/'target'))
start_wall=time.time(); start=time.monotonic(); record=dict(source_sha=source,main_sha='4dabf06ef90c8c9e8c459b524b509af3a2e98b31',merge_tree='2de5287d691c34d7170969d006bc28457ae36f00',run_id=run_id,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),profile='ci',test_threads=4,build_jobs=4,nice=19,group_config_sha256=config,unfiltered=True,phase='running',host_samples=[])
path=out/'hint-fixed-tree-time.json'; path.write_text(json.dumps(record,indent=2)+'\n')
with (out/'hint-fixed-tree-suite.log').open('w') as log:
 child=subprocess.Popen(argv,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while child.poll() is None:
   names=collections.Counter(subprocess.check_output(['ps','-eo','comm='],text=True).split())
   if len(record['host_samples'])<4096:record['host_samples'].append(dict(offset_s=round(time.monotonic()-start,3),load=os.getloadavg(),processes={k:names[k] for k in ['cargo','cargo-nextest','rustc','clippy-driver']}))
   time.sleep(2)
 except BaseException:
  if child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  raise
 finally:
  record.update(exit_code=child.returncode,command_wall_seconds=round(time.monotonic()-start,3),end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase='complete')
  record['observed_max_process_counts']={k:max((s['processes'][k] for s in record['host_samples']),default=0) for k in ['cargo','cargo-nextest','rustc','clippy-driver']}
  path.write_text(json.dumps(record,indent=2)+'\n')
  junit=root/'target/nextest/ci/junit.xml'
  if junit.exists() and junit.stat().st_mtime >= start_wall:
   shutil.copy2(junit,out/'hint-fixed-tree-junit.xml')
  with (out/'hint-fixed-tree-cleanup.log').open('w') as cleanup:
   check=subprocess.run(['scripts/check-no-leaked-processes','--run-id',run_id],stdout=cleanup,stderr=subprocess.STDOUT)
  record['cleanup_exit_code']=check.returncode
  path.write_text(json.dumps(record,indent=2)+'\n')
print('Merge-tree suite exit',child.returncode,'wall',record['command_wall_seconds'],flush=True)
raise SystemExit(child.returncode or record['cleanup_exit_code'])
